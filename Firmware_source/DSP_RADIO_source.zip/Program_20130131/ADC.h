//**********************
// ADC header
// 
// (C)Copyright 2010 All rights reserved by Y.Onodera
// http://einstlab.web.fc2.com
//**********************

#define ALALOG	1
#define DIGITAL	0
#define INPUT	1
#define OUTPUT	0


// Function prototypes
void InitADC();
unsigned int GetADC();



