//**********************
// Timer for PIC16F88 or PIC16F1827
//
// Condition:
// Source: Timer.c, Timer.h
//
// (C)Copyright 2010 All rights reserved by Y.Onodera
// http://einstlab.web.fc2.com
//**********************
#include <xc.h>


void InitTMR0(){

	// TMR0fy=(FOSC/4)/Prescaler{256,128,64,32,16,8,4,2}/(0x100-TMR0)
	// 100KHz=(8MHz/4)/2/(0x100-0xF6), 10us
	// 50KHz=(8MHz/4)/4/(0x100-0xF6), 20us
	// 30.52Hz=(8MHz/4)/256/(0x100-0)
	// 5.008Hz=(1MHz/4)/256/(0x100-0x3D)

	CLRWDT();
	// Timer 0 init
	TMR0 = 0x00;	// Initialize
	// T1CON setting
	T0CS = 0;		// 1:T0CKI, 0:internal CLKO
	T0SE = 0;		// 1:high to low, 0:low to hight
	PSA = 0;		// 1:WDT, 0:Timer0
	PS2 = 1;		// 000=1:2, 001=1:4, 010=1:8, 011=1:16, 100=1:32, 101= 1:64, 110=1:128, 111=1:256
	PS1 = 1;
	PS0 = 1;
	TMR0IF = 0;		// clear interrupt flag
	TMR0IE = 1;		// TMR1 interrupt enable
	PEIE = 1;		// Peripheral interrupt
	GIE = 1;		// Global interrupt enable

}


void InitTMR1(){

	// TMR1fy=(FOSC/4)/Prescaler{8,4,2,1}/(0xFFFF-TMR1H:TMR1L)
	// 10Hz=(8MHz/4)/8/(0x10000-0x9E58)
	// 0.48Hz=(1MHz/4)/8/(0x10000)
	// 0.24Hz=(500Hz/4)/8/(0x10000)
	// 0.12Hz=(250Hz/4)/8/(0x10000)

	// Timer 1 init
	TMR1L = 0x00;	// First
	TMR1H = 0x00;	// Initialize
	// T1CON setting
	T1CKPS1 = 1;	// 11=1:8, 10=1:4, 01=1:2, 00=1:1
	T1CKPS0 = 1;
	T1OSCEN = 0;	// 1=enable, 0=disable
	nT1SYNC = 1;		// 0=Sync, 1=Ansync
#if defined(_16F88)
	TMR1CS = 0;		// 1=External clck, 0=Internal clock(FOSC/4)
#endif
#if defined(_16F1827)||defined(_16F1847)
	TMR1CS1 = 0;		// 11=CAPOSC, 10=External
	TMR1CS0 = 0;		// 01=Internal clock(FOSC), 00=Internal clock(FOSC/4)
#endif
	TMR1ON = 1;		// 1=enable, 0=disable
	TMR1IF = 0;		// clear interrupt flag
	TMR1IE = 1;		// TMR1 interrupt enable
	PEIE = 1;		// Peripheral interrupt
	GIE = 1;		// Global interrupt enable

}

extern unsigned char DUTY;
void InitTMR2(){

	// TMR2fy=(FOSC/4)/Prescaler{16,4,1}/(PR2+1)/Postscaler{16 - 1}
	// 100Hz=(8MHz/4)/16/(249+1)/5
	// 1000Hz=(1MHz/4)/1/(249+1)/1
	// 5000Hz=(1MHz/4)/1/(49+1)/1
	// 10000Hz=(1MHz/4)/1/(24+1)/1

	// period=200us
	// duty=1us

	// Timer 2 init
	TMR2 = 0x00;	// Initialize
	PR2 = 24;		// 1 to 255
#if defined(_16F88)
	// T2CON setting
	T2CKPS1 = 1;	// 00=1, 01=4, 1x=16
	T2CKPS0 = 0;
	TOUTPS3 = 0;	// 0000=1, 0001=2, ,1111=16
	TOUTPS2 = 1;
	TOUTPS1 = 0;
	TOUTPS0 = 0;
#endif
#if defined(_16F1827)||defined(_16F1847)
	T2CONbits.T2CKPS = 0;	// Prescaler 00=1, 01=4, 10=16, 11=64
	T2CONbits.T2OUTPS = 0;	// Postscaler 0000=1, 0001=2, ,1111=16
#endif

	TRISA4=0;	// CCP4 = output
	ANSA4=0;
	CCPR4L=DUTY>>2;	//  Duty=(CCPR1L:CCP1CON<5:4>)*Tosc*Pre
	CCP4CONbits.DC4B=(DUTY&0x03);		// LSB of CCPR1L
	CCP4CONbits.CCP4M=0xC;	// PWM mode
	CCPTMRSbits.C4TSEL=0;	// CCP4 with Timer 2

	TMR2ON = 1;		// 1=enable, 0=disable
	TMR2IF = 0;		// clear interrupt flag
	TMR2IE = 0;		// TMR2 interrupt enable
	PEIE = 1;		// Peripheral interrupt
	GIE = 1;		// Global interrupt enable

}

