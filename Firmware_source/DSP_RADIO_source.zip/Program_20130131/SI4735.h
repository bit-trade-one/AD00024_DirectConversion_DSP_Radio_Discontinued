//**********************
// SI4735 Function
// 
// (C)Copyright 2012 All rights reserved by Y.Onodera
// http://einstlab.web.fc2.com
//**********************
#include <xc.h>

unsigned char rssi;
unsigned char stereo;
WORD_VAL minf, maxf;


#define RST	RA7
#define TRIS_RST	TRISA7
#define SI4735_W	0x22	// SENB=0
#define SI4735_R	0x23
//#define SI4735_W	0xC6	// SENB=1
//#define SI4735_R	0xC7
#define MIN_FM		7600	// 76.00MHz
#define MAX_FM		9000	// 90.00MHz
#define MIN_AM		522		//  522KHz=0x020A
#define MAX_AM		1629	// 1629KHz=0x065D
#define MIN_VOL		0
#define MAX_VOL		0x3F
#define SPACING_FM	0x0A	// 100KHz
#define SPACING_AM	0x09	// 9KHz



// Function prototypes
void SetProperty(unsigned char a,unsigned char b,unsigned char c,unsigned char d);
void SetVolume(unsigned char v);
unsigned char GetFMStatus();
unsigned char GetAMStatus();
void SetFMRadio(unsigned int f);
void SetAMRadio(unsigned int f);
unsigned int GetFMRadio();
unsigned int GetAMRadio();
void SeekFMRadio();
void SeekAMRadio();
void InitFMRadio(unsigned int fmin, unsigned int fmax, unsigned char spacing);
void InitAMRadio(unsigned int fmin, unsigned int fmax, unsigned char spacing);
//void PowerDown();
void ResetRadio();

