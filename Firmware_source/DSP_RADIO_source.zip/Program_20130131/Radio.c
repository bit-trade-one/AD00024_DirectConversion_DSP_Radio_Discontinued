//**********************
// AM/FM radio program for PIC16F1827
//
// FM
// US    87.50MHz - 108.00MHz
// Japan 76.00MHz - 90.00MHz
//
// AM
// Japan 522KHz - 1629KHz
// ANTCAP=6143
// Max 95fF*ANTCAP + 7pF=590pF
//
// To reset for factory default
// SW3=ON and SW4=ON then power on
//
// Condition: INTOSC 1MHz
// Fcy=FOSC/4=4us
// Timer1=0.48Hz
// Timer2=10KHz
//
// (C)Copyright 2012 All rights reserved by Y.Onodera
// http://einstlab.web.fc2.com
//**********************
#include <xc.h>		// XC8
#include <stdio.h>
#include "Wait.h"
#include "LCD.h"
#include "I2C.h"
#include "Timer.h"
#include "ADC.h"
#include "typedef.h"
#include "SI4735.h"

// for PIC16F1827
__CONFIG(FOSC_INTOSC & WDTE_OFF & PWRTE_OFF & MCLRE_OFF & CP_ON & CPD_OFF & BOREN_OFF & CLKOUTEN_OFF & IESO_OFF & FCMEN_OFF);	// config1
__CONFIG(WRT_OFF & PLLEN_OFF & STVREN_OFF & BORV_LO & LVP_OFF);			// config2


// as byte
// AM/FM=0/1, 8000MHz=0x1F40, 954KHz=0x03BA, volume
__EEPROM_DATA(0x01,0x40,0x1F,0xBA,0x03,0x30,0xFF,0xFF);

unsigned char flag;	// function
unsigned char band;
unsigned char volume;
WORD_VAL frequency;
char msg1[18];
char msg2[18];
unsigned char DUTY;

// for SC1602
// const unsigned char contrast[]={2,2,3,3,3,4,5,7,10,22,30};
// for WH1602
//const unsigned char contrast[]={3,3,4,4,5,6,7,10,22,30,30};
const unsigned char contrast[]={2,2,3,3,3,4,5,6,7,10,22,30,30};


// switch
#define SW1	RB7
#define SW2	RB6
#define SW3	RB5
#define SW4	RB4
#define TRIS_SW1	TRISB7
#define TRIS_SW2	TRISB6
#define TRIS_SW3	TRISB5
#define TRIS_SW4	TRISB4
#define CFG_SW1		ANSB7
#define CFG_SW2		ANSB6
#define CFG_SW3		ANSB5
#define CFG_SW4		ANSB4
#define SW1F		IOCBF7
#define SW2F		IOCBF6
#define SW3F		IOCBF5
#define SW4F		IOCBF4


// Timer1 runs on sleep mode.
void interrupt isr(void)
{
	// Timer subroutine
	if (TMR0IE && TMR0IF) {
		TMR0IF=0;	// clear interrupt flag
	}
	if (TMR1IE && TMR1IF) {
		if(flag==0){
			flag=3;
		}
		TMR1IF=0;	// clear interrupt flag
	}
	// other interrupt sources here
	if (IOCIE && IOCIF) {
		if(SW1F==1){
			if(flag==0)flag=4;
			SW1F=0;	// clear flag
		}
		if(SW2F==1){
			if(flag==0)flag=1;
			SW2F=0;	// clear flag
		}
		if(SW3F==1){
			if(volume<MAX_VOL && flag==0){
				++volume;
				flag=2;
			}
			SW3F=0;	// clear flag
		}
		if(SW4F==1){
			if(MIN_VOL<volume && flag==0){
				--volume;
				flag=2;
			}
			SW4F=0;	// clear flag
		}

	}
	if (TMR2IE && TMR2IF) {
		TMR2IF=0;	// clear interrupt flag
	}
}


void KeepFrequency(){

	if(band){
		eeprom_write(1,frequency.byte.LB);
		eeprom_write(2,frequency.byte.HB);
	}else{
		eeprom_write(3,frequency.byte.LB);
		eeprom_write(4,frequency.byte.HB);
	}

}


void InitFrequency(){

	if(band){
		frequency.byte.LB=eeprom_read(1);
		frequency.byte.HB=eeprom_read(2);
		SetFMRadio(frequency.Val);
	}else{
		frequency.byte.LB=eeprom_read(3);
		frequency.byte.HB=eeprom_read(4);
		SetAMRadio(frequency.Val);
	}

}


void InitBand(){

	ResetRadio();
//	PowerDown();

	band = eeprom_read(0);
	volume = eeprom_read(5);
	if(band){
		InitFMRadio(MIN_FM, MAX_FM, SPACING_FM);
	}else{
		InitAMRadio(MIN_AM, MAX_AM, SPACING_AM);
	}
	InitFrequency();
	SetVolume(volume);

}


// Main routine
int main(void)
{

	char i;

	// change OSC
	SPLLEN=0;	// 0:PLL_OFF 1:PLL_ON
//	OSCCONbits.IRCF=0x0F;	// INTOSC=16MHz HF
//	OSCCONbits.IRCF=0x0E;	// INTOSC=8MHz HF
//	OSCCONbits.IRCF=0x0D;	// INTOSC=4MHz HF
//	OSCCONbits.IRCF=0x0C;	// INTOSC=2MHz HF
	OSCCONbits.IRCF=0x0B;	// INTOSC=1MHz HF
//	OSCCONbits.IRCF=0x0A;	// INTOSC=500KHz HF
//	OSCCONbits.IRCF=0x09;	// INTOSC=250KHz HF
//	OSCCONbits.IRCF=0x08;	// INTOSC=125KHz HF
//	OSCCONbits.IRCF=0x07;	// INTOSC=500KHz MF default
//	OSCCONbits.IRCF=0x06;	// INTOSC=250KHz MF
//	OSCCONbits.IRCF=0x05;	// INTOSC=125KHz MF
//	OSCCONbits.IRCF=0x04;	// INTOSC=62.5KHz MF
//	OSCCONbits.IRCF=0x03;	// INTOSC=31.25KHz HF
//	OSCCONbits.IRCF=0x02;	// INTOSC=31.25KHz MF
//	OSCCONbits.IRCF=0x00;	// INTOSC=31KHz
	OSCCONbits.SCS=0x00;
//	OSCTUNE=0x3D;	// -0.16%  5%/63=0.08%
#ifndef __DEBUG
	while(HFIOFR==0);	// wait stable
//	while(MFIOFR==0);	// wait stable
#endif

	// port init for PIC16F1827
	nWPUEN = 0;		// PORTB pull-up enable
	WPUB = 0xF0;

	CFG_SW1 = 0;
	CFG_SW2 = 0;
	CFG_SW3 = 0;
	CFG_SW4 = 0;
	SW1 = 1;
	SW2 = 1;
	SW3 = 1;
	SW4 = 1;
	TRIS_SW1 = 1;
	TRIS_SW2 = 1;
	TRIS_SW3 = 1;
	TRIS_SW4 = 1;

	InitADC();
	InitI2C();

	// LCD init
	InitLCD();
	// turn on
	PutCmdLCD(DISPLAY_ON & CURSOR_OFF & BLINK_OFF);
//	ClsLCD();

	// reset for factory default
	if(SW3==0 && SW4==0){
		band=0;
		frequency.Val=954;
		KeepFrequency();
		band=1;
		frequency.Val=8000;
		KeepFrequency();
	}

//	ResetRadio();
	InitBand();
	InitFrequency();
	flag = 3;


	// Timer 1 init to get stereo signal
	InitTMR1();
	InitTMR2();	// CCP4 pwm


	// RB ���荞�݂̐ݒ�
	IOCBN4 = 1;	// low edge
	IOCBN5 = 1;	// low edge
	IOCBN6 = 1;	// low edge
	IOCBN7 = 1;	// low edge
	IOCIE = 1;
	PEIE = 1;		// �y���t�F�������荞�݋��� for RB
	GIE = 1;		// �O���[�o�����荞�݋���


	// main loop
	while(1)
	{

		// idle
		if (flag > 0){
			if(flag==1){
				sprintf(msg1,"Tuning..");
				LocateLCD(0,0);
				PutsLCD(msg1);

				if(band){
					SeekFMRadio();
					frequency.Val=GetFMRadio();
				}else{
					SeekAMRadio();
					frequency.Val=GetAMRadio();
				}
				KeepFrequency();

			}
			if(flag==2){
				SetVolume(volume);
				eeprom_write(5,volume);
			}
			if(flag==3){
				if(band){
					GetFMStatus();
				}else{
					GetAMStatus();
				}
			}
			if(flag==4){
				band = band ? 0 : 1;
				eeprom_write(0,band);
				InitBand();
			}

			if(band){
				if(stereo&0x80){
					sprintf(msg1,"FM radio*RSSI=%2d",rssi);
				}else{
					sprintf(msg1,"FM radio RSSI=%2d",rssi);
				}
				sprintf(msg2,"%3d.%02dMHz Vol=%2d", frequency.Val/100, frequency.Val%100, volume);
			}else{
				sprintf(msg1,"AM radio RSSI=%2d",rssi);
				sprintf(msg2,"  %4dKHz Vol=%2d", frequency.Val, volume);
			}

			// Set LCD contrast as PWM
			i=32-10486/GetADC();	// 32-20=3.2-2.0[V]
			if(i>0x7F)i=0;
			if(i>12)i=12;
			DUTY=contrast[i];
			CCPR4L=DUTY>>2;	//  Duty=(CCPR1L:CCP1CON<5:4>)*Tosc*Pre
			CCP4CONbits.DC4B=(DUTY&0x03);		// LSB of CCPR1L

			LocateLCD(0,0);
			PutsLCD(msg1);
			LocateLCD(0,1);
			PutsLCD(msg2);
			flag = 0;

		}

	}
}

