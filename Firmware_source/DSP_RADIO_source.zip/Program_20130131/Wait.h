//**********************
// Wait header
//
// (C)Copyright 2010 All rights reserved by Y.Onodera
// http://einstlab.web.fc2.com
//**********************
// define clock
//#define _XTAL_FREQ 32000000
//#define _XTAL_FREQ 20000000
//#define _XTAL_FREQ 16000000
//#define _XTAL_FREQ 10000000
//#define _XTAL_FREQ 8000000
//#define _XTAL_FREQ 4000000
#define _XTAL_FREQ 1000000
//#define _XTAL_FREQ 500000
//#define _XTAL_FREQ 250000
//#define _XTAL_FREQ 125000
//#define _XTAL_FREQ 31250


#define WaitNus(n) __delay_us(n)
#define WaitNms(n) __delay_ms(n)

