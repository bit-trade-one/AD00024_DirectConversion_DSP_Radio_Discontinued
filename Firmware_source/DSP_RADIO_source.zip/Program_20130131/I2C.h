//**********************
// I2C Function
// 
// (C)Copyright 2010 All rights reserved by Y.Onodera
// http://einstlab.web.fc2.com
//**********************
#include <xc.h>


#define BPS	100000	//100Kbps=5us pulse
//#define BPS	400000	//400Kbps=1.25us pulse
//#define BPS	1000000	//1Mbps=0.5us pulse

#define ACK	0
#define NACK	1

#define SCL	RA6
#define SDA	RA3
#define TRIS_SCL	TRISA6
#define TRIS_SDA	TRISA3
//#define CFG_SCL	ANSA6
#define CFG_SDA	ANSA3


// Function prototypes
void delay_I2C();
void InitI2C();
void StartI2C();
void StopI2C();
unsigned char PutI2C(unsigned char a);
unsigned char GetI2C(unsigned char ack);


