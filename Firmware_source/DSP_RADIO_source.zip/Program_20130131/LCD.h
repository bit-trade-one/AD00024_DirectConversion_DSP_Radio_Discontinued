//**********************
// LCD header
// 
// (C)Copyright 2009 All rights reserved by Y.Onodera
// http://einstlab.web.fc2.com
//**********************
#include <xc.h>


// Select LCD type for locateLCD
//#define DISPLAY_8x1
//#define DISPLAY_8x2
//#define DISPLAY_10x1
//#define DISPLAY_10x4
//#define DISPLAY_16x1
#define DISPLAY_16x2
//#define DISPLAY_16x4
//#define DISPLAY_20x2
//#define DISPLAY_20x4
//#define DISPLAY_24x2
//#define DISPLAY_40x2
//#define DISPLAY_40x4	// not yet implementation


// Default 4 bits interface

// define data PIN assignment
#define DATA_PIN_7			RB3
#define DATA_PIN_6			RB2
#define DATA_PIN_5			RB1
#define DATA_PIN_4			RB0
#define TRIS_DATA_PIN_7		TRISB3
#define TRIS_DATA_PIN_6		TRISB2
#define TRIS_DATA_PIN_5		TRISB1
#define TRIS_DATA_PIN_4		TRISB0
#define CFG_DATA_PIN_7		ANSB3
#define CFG_DATA_PIN_6		ANSB2
#define CFG_DATA_PIN_5		ANSB1
//#define CFG_DATA_PIN_4		ANSB0
#define READ_PIN_7			RB3
#define READ_PIN_6			RB2
#define READ_PIN_5			RB1
#define READ_PIN_4			RB0


// Define control PIN assignment
#define E_PIN				RA0
#define RW_PIN				RA1
#define RS_PIN				RA2
#define TRIS_E				TRISA0
#define TRIS_RW				TRISA1
#define TRIS_RS				TRISA2
#define CFG_E_PIN			ANSA0
#define CFG_RW_PIN			ANSA1
#define CFG_RS_PIN			ANSA2

// Instructions
#define CLEAR_DISPLAY		0x01	// Clear Display
#define RETURN_HOME			0x02	// Return Home
// for Entry Mode Set
#define INC_MODE			0x07	// Increment mode
#define DEC_MODE			0x05	// Decrement mode
#define SHIFT_OFF			0x06	// Do not Shift Display
#define SHIFT_ON			0x07	// Shift Display
// for Display ON/OFF Control
#define DISPLAY_ON			0x0f	// Display on
#define DISPLAY_OFF			0x0b	// Display off
#define CURSOR_ON			0x0f	// Cursor on
#define CURSOR_OFF			0x0d	// Cursor off
#define BLINK_ON			0x0f	// Cursor Blink
#define BLINK_OFF			0x0e	// Cursor No Blink
// for Cursor or Display Shift
#define SHIFT_CUR_LEFT		0x13	// Shift Cursor to the left
#define SHIFT_CUR_RIGHT		0x17	// Shift Cursor to the right
#define SHIFT_DISP_LEFT		0x1b	// Shift Display to the left
#define SHIFT_DISP_RIGHT	0x1f	// Shift Display to the right
// for Function Set
#define FOUR_BIT			0x2f	// 4-bit Interface
#define EIGHT_BIT			0x3f	// 8-bit Interface
#define ONE_LINE			0x37	// One line
#define TWO_LINE			0x3f	// Two lines
#define DOTS_5x8			0x3b	// 5x8 dots
#define DOTS_5x10			0x3f	// 5x10 dots


// Set Initial Mode for Function Set
#define INIT_MODE	(FOUR_BIT & TWO_LINE & DOTS_5x10)


// Function prototypes
void PutLCD(int rs, char a);
char GetLCD(int rs);
void InitLCD();
void ClsLCD();
void LocateLCD(int x, int y);
void PutsLCD(char *buffer);


#define	PutcLCD(a)	PutLCD(1, a)
#define	PutCmdLCD(a)	PutLCD(0, a)
#define	PutDatLCD(a)	PutLCD(1, a)
#define	GetCmdLCD()	GetLCD(0)
#define	GetDatLCD()	GetLCD(1)


