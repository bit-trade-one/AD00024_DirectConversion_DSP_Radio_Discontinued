//**********************
// Timer for PIC16F88
//
// Condition:
// Source: Timer.c, Timer.h
//
// (C)Copyright 2010 All rights reserved by Y.Onodera
// http://einstlab.web.fc2.com
//**********************


void InitTMR0();
void InitTMR1();
void InitTMR2();

